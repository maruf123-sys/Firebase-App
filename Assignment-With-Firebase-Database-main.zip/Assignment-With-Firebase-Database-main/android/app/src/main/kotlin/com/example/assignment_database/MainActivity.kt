package com.example.assignment_database

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
